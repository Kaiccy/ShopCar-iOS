//
//  ViewController.m
//  ShopCar
//
//  Created by YZBookPro on 2019/5/16.
//  Copyright © 2019年 YZBookPro. All rights reserved.
//

#import "ViewController.h"
#import "Goods.h"
#import "MJExtension.h"
#import "Masonry.h"
#import "GoodsCell.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource,GoodsCellDelegate>

///列表
@property (nonatomic, strong) UITableView *tableView;
///全选按钮
@property (nonatomic, strong) UIButton *selectAllBtn;
///总价label
@property (nonatomic, strong) UILabel *totalPriceL;
///所有商品数组
@property (nonatomic, strong) NSArray *goodsArr;
///被选中数组
@property (nonatomic, strong) NSMutableArray *selectArr;
///是否全选
@property (nonatomic, assign) BOOL isSelectAll;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _isSelectAll = NO;
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"GoodsList" ofType:nil];
    NSData *data = [NSData dataWithContentsOfFile:path];
    self.goodsArr  = [Goods mj_objectArrayWithKeyValuesArray:data];
    
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.selectAllBtn];
    [self.view addSubview:self.totalPriceL];
    [self setLayout];
    
    //按钮切圆
//    _selectAllBtn.layer.cornerRadius = 10.0f;
//    _selectAllBtn.layer.masksToBounds = YES;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self->_selectAllBtn.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:self->_selectAllBtn.bounds.size];
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
        //设置大小
        maskLayer.frame = self->_selectAllBtn.bounds;
        //设置图形样子
        maskLayer.path = maskPath.CGPath;
        self->_selectAllBtn.layer.mask = maskLayer;
    });
}

- (void) setLayout{
    [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.mas_equalTo(0);
        make.bottom.mas_equalTo(-100);
        make.width.mas_equalTo(self.view);
    }];
    [_selectAllBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.mas_equalTo(20);
        make.bottom.mas_equalTo(-30);
        make.left.mas_equalTo(30);
    }];    
    [_totalPriceL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self->_selectAllBtn);
        make.left.equalTo(self->_selectAllBtn.mas_right).mas_equalTo(10);
    }];
}


#pragma uitableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _goodsArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    GoodsCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([GoodsCell class])];
    cell.goods = _goodsArr[indexPath.row];
    cell.row = indexPath.row;
    cell.delegate = self;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100;
}

#pragma GoodsCellDelegate

- (void)goodsCellReduceNum:(NSString *)num row:(NSInteger)row selected:(BOOL)selected{
    Goods *goods = _goodsArr[row];
    goods.num = num;
    if (selected) {
        [self showTotalMoney];
    }
}

- (void)goodsCellAddNum:(NSString *)num row:(NSInteger)row selected:(BOOL)selected{
    Goods *goods = _goodsArr[row];
    goods.num = num;
    if (selected) {
        [self showTotalMoney];
    }
}

- (void)goodsCellSelectGoods:(NSInteger)row selected:(BOOL)selected{
    if (selected) {
        [self.selectArr addObject:_goodsArr[row]];
    }else{
        [self.selectArr removeObject:_goodsArr[row]];
    }
    [self showTotalMoney];
    //检测是否全选
    if (_selectArr.count == _goodsArr.count) {
        self.isSelectAll = YES;
    }else{
        self.isSelectAll = NO;
    }
}

#pragma action
- (void)selectAllAction{
    self.isSelectAll = !_isSelectAll;
    for (int i = 0; i < _goodsArr.count; i ++) {
        GoodsCell *cell = [_tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        cell.isSelect = _isSelectAll;
    }
    [self.selectArr removeAllObjects];
    if (_isSelectAll) {
        [self.selectArr addObjectsFromArray:_goodsArr];
    }
    [self showTotalMoney];
}

- (void)showTotalMoney{
    CGFloat total = [self caculateTotalMoney];
    _totalPriceL.text = [NSString stringWithFormat:@"%.2f",total];
}

- (CGFloat)caculateTotalMoney{
    CGFloat total = 0;
    for (Goods *goods in _selectArr) {
        total = total + goods.num.integerValue * goods.price.floatValue;
    }
    return total;
}

#pragma setter getter

- (UITableView *)tableView{
    if (_tableView == nil) {
        _tableView = [[UITableView alloc] init];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerNib:[UINib nibWithNibName:NSStringFromClass([GoodsCell class]) bundle:nil] forCellReuseIdentifier:NSStringFromClass([GoodsCell class])];
    }
    return _tableView;
}

- (UIButton *)selectAllBtn{
    if (_selectAllBtn == nil) {
        _selectAllBtn  = [[UIButton alloc] init];
        _selectAllBtn.backgroundColor = [UIColor lightGrayColor];
        [_selectAllBtn addTarget:self action:@selector(selectAllAction) forControlEvents:(UIControlEventTouchUpInside)];
    }
    return _selectAllBtn;
}

- (UILabel *)totalPriceL{
    if (_totalPriceL == nil) {
        _totalPriceL  = [[UILabel alloc] init];
        _totalPriceL.text = @"￥0.00";
        _totalPriceL.font = [UIFont systemFontOfSize:15];
        _totalPriceL.textColor = [UIColor greenColor];
    }
    return _totalPriceL;
}

- (NSMutableArray *)selectArr{
    if (_selectArr == nil) {
        _selectArr = [[NSMutableArray alloc] init];
    }
    return _selectArr;
}

- (void)setIsSelectAll:(BOOL)isSelectAll{
    _isSelectAll = isSelectAll;
    if (_isSelectAll) {
        _selectAllBtn.backgroundColor = [UIColor greenColor];
    }else{
        _selectAllBtn.backgroundColor = [UIColor lightGrayColor];
    }
}

@end
