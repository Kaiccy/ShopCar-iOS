//
//  GoodsCell.h
//  ShopCar
//
//  Created by YZBookPro on 2019/5/16.
//  Copyright © 2019年 YZBookPro. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Goods.h"

@protocol GoodsCellDelegate <NSObject>

- (void)goodsCellAddNum:(NSString *)num row:(NSInteger)row selected:(BOOL)selected;

- (void)goodsCellReduceNum:(NSString *)num row:(NSInteger)row selected:(BOOL)selected;

- (void)goodsCellSelectGoods:(NSInteger)row selected:(BOOL)selected;

@end

NS_ASSUME_NONNULL_BEGIN

@interface GoodsCell : UITableViewCell

@property (nonatomic, strong) Goods *goods;

@property (nonatomic, assign) NSInteger row;

@property (nonatomic, assign) BOOL isSelect;

@property (nonatomic, assign) id<GoodsCellDelegate> delegate;

@end

NS_ASSUME_NONNULL_END
