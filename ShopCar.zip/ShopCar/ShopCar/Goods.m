//
//  Goods.m
//  ShopCar
//
//  Created by YZBookPro on 2019/5/16.
//  Copyright © 2019年 YZBookPro. All rights reserved.
//

#import "Goods.h"

@implementation Goods

@end
