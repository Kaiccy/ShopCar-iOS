//
//  Goods.h
//  ShopCar
//
//  Created by YZBookPro on 2019/5/16.
//  Copyright © 2019年 YZBookPro. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Goods : NSObject

@property (nonatomic, strong) NSString *name;

@property (nonatomic, strong) NSString *price;

@property (nonatomic, strong) NSString *num;

@end

NS_ASSUME_NONNULL_END
