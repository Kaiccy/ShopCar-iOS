//
//  GoodsCell.m
//  ShopCar
//
//  Created by YZBookPro on 2019/5/16.
//  Copyright © 2019年 YZBookPro. All rights reserved.
//

#import "GoodsCell.h"

@interface GoodsCell ()

@property (weak, nonatomic) IBOutlet UIButton *selectBtn;

@property (weak, nonatomic) IBOutlet UILabel *nameL;

@property (weak, nonatomic) IBOutlet UILabel *priceL;

@property (weak, nonatomic) IBOutlet UIButton *reduceBtn;

@property (weak, nonatomic) IBOutlet UIButton *addBtn;

@property (weak, nonatomic) IBOutlet UILabel *numL;

@end

@implementation GoodsCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.isSelect = NO;
    
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_selectBtn.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:_selectBtn.bounds.size];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
    //设置大小
    maskLayer.frame = _selectBtn.bounds;
    //设置图形样子
    maskLayer.path = maskPath.CGPath;
    _selectBtn.layer.mask = maskLayer;
}

- (void)setGoods:(Goods *)goods{
    _goods = goods;
    _nameL.text = goods.name;
    _priceL.text = [NSString stringWithFormat:@"￥%@",goods.price];
    _numL.text = goods.num;
}

- (void)setIsSelect:(BOOL)isSelect{
    _isSelect = isSelect;
    if (_isSelect) {
        _selectBtn.backgroundColor = [UIColor greenColor];
    }else{
        _selectBtn.backgroundColor = [UIColor lightGrayColor];
    }
}

- (IBAction)selectAction:(UIButton *)sender {
    self.isSelect = !_isSelect;
    
    if ([self.delegate respondsToSelector:@selector(goodsCellSelectGoods:selected:)]) {
        [self.delegate goodsCellSelectGoods:_row selected:_isSelect];
    }
}

- (IBAction)reduceAction:(UIButton *)sender {
    NSInteger num = _numL.text.integerValue;
    if (num > 1) {
        _numL.text = [NSString stringWithFormat:@"%ld",--num];
        if ([self.delegate respondsToSelector:@selector(goodsCellReduceNum:row:selected:)]) {
            [self.delegate goodsCellReduceNum:_numL.text row:_row selected:_isSelect];
        }
    }
}

- (IBAction)addAction:(UIButton *)sender {
    NSInteger num = _numL.text.integerValue;
    _numL.text = [NSString stringWithFormat:@"%ld",++num];
    if ([self.delegate respondsToSelector:@selector(goodsCellAddNum:row:selected:)]) {
        [self.delegate goodsCellAddNum:_numL.text row:_row selected:_isSelect];
    }
}




- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
